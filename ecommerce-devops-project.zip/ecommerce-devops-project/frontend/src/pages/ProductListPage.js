import React, { useEffect, useState } from 'react';
import { productApi } from '../api';

function ProductListPage() {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    productApi.get('/products')
      .then((res) => setProducts(res.data))
      .catch((err) => setError(err.message));
  }, []);

  if (error) return <p>Could not load products: {error}</p>;

  return (
    <div>
      <h2>Products</h2>
      <ul>
        {products.map((p) => (
          <li key={p.id}>
            {p.name} — ${p.price} ({p.stockQuantity} in stock)
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ProductListPage;
