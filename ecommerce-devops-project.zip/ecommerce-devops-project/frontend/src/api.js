import axios from 'axios';

// In k8s these will be routed through the Ingress; locally they hit
// the API Gateway / individual services directly via docker-compose ports.
const USER_SERVICE_URL = process.env.REACT_APP_USER_SERVICE_URL || 'http://localhost:8081';
const PRODUCT_SERVICE_URL = process.env.REACT_APP_PRODUCT_SERVICE_URL || 'http://localhost:8082';
const CART_SERVICE_URL = process.env.REACT_APP_CART_SERVICE_URL || 'http://localhost:8083';
const ORDER_SERVICE_URL = process.env.REACT_APP_ORDER_SERVICE_URL || 'http://localhost:8084';

export const userApi = axios.create({ baseURL: USER_SERVICE_URL });
export const productApi = axios.create({ baseURL: PRODUCT_SERVICE_URL });
export const cartApi = axios.create({ baseURL: CART_SERVICE_URL });
export const orderApi = axios.create({ baseURL: ORDER_SERVICE_URL });
