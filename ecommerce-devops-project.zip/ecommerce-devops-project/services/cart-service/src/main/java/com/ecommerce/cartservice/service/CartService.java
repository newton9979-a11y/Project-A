package com.ecommerce.cartservice.service;

import com.ecommerce.cartservice.dto.AddItemRequest;
import com.ecommerce.cartservice.model.Cart;
import com.ecommerce.cartservice.model.CartItem;
import com.ecommerce.cartservice.repository.CartRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CartService {

    private final CartRepository cartRepository;

    public Cart getCart(String userId) {
        return cartRepository.findByUserId(userId);
    }

    public Cart addItem(String userId, AddItemRequest request) {
        Cart cart = cartRepository.findByUserId(userId);

        cart.getItems().stream()
                .filter(item -> item.getProductId().equals(request.getProductId()))
                .findFirst()
                .ifPresentOrElse(
                        existing -> existing.setQuantity(existing.getQuantity() + request.getQuantity()),
                        () -> cart.getItems().add(new CartItem(
                                request.getProductId(), request.getProductName(),
                                request.getPrice(), request.getQuantity()))
                );

        cartRepository.save(cart);
        return cart;
    }

    public Cart removeItem(String userId, String productId) {
        Cart cart = cartRepository.findByUserId(userId);
        cart.getItems().removeIf(item -> item.getProductId().equals(productId));
        cartRepository.save(cart);
        return cart;
    }

    public void clearCart(String userId) {
        cartRepository.delete(userId);
    }
}
