package com.ecommerce.cartservice.repository;

import com.ecommerce.cartservice.model.Cart;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

/**
 * Carts are stored in Redis as "cart:{userId}" -> Cart, with a TTL so
 * abandoned carts expire automatically instead of growing forever.
 */
@Repository
public class CartRepository {

    private static final String KEY_PREFIX = "cart:";
    private static final long TTL_HOURS = 24;

    private final RedisTemplate<String, Cart> redisTemplate;

    public CartRepository(RedisTemplate<String, Cart> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public Cart findByUserId(String userId) {
        Cart cart = redisTemplate.opsForValue().get(KEY_PREFIX + userId);
        if (cart == null) {
            cart = new Cart(userId, new java.util.ArrayList<>());
        }
        return cart;
    }

    public void save(Cart cart) {
        redisTemplate.opsForValue().set(KEY_PREFIX + cart.getUserId(), cart,
                java.time.Duration.ofHours(TTL_HOURS));
    }

    public void delete(String userId) {
        redisTemplate.delete(KEY_PREFIX + userId);
    }
}
