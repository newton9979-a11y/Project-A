package com.ecommerce.cartservice;

import org.junit.jupiter.api.Test;

class CartServiceApplicationTests {

    @Test
    void contextLoads() {
        // Full Spring context test requires a Redis instance (e.g. via Testcontainers).
        // Kept as a placeholder here; wire up Testcontainers in a later phase.
    }
}
