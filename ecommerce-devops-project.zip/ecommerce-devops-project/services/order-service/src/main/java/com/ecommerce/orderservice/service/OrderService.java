package com.ecommerce.orderservice.service;

import com.ecommerce.orderservice.client.PaymentClient;
import com.ecommerce.orderservice.client.ProductClient;
import com.ecommerce.orderservice.dto.OrderCreateRequest;
import com.ecommerce.orderservice.exception.OrderNotFoundException;
import com.ecommerce.orderservice.model.Order;
import com.ecommerce.orderservice.model.OrderStatus;
import com.ecommerce.orderservice.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * Orchestrates order creation across product-service and payment-service:
 *
 *   1. Look up the product (price + confirm it exists) via ProductClient
 *   2. Reserve stock for the requested quantity
 *   3. Persist the order as CREATED
 *   4. Charge payment-service for the total
 *   5. Update order status to CONFIRMED or PAYMENT_FAILED based on the result
 *
 * This is a simple synchronous saga. A production version would likely move
 * to an async choreography (events + compensating actions) so a slow or down
 * payment-service doesn't block the whole request — worth calling out as a
 * "next iteration" talking point in interviews.
 */
@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductClient productClient;
    private final PaymentClient paymentClient;

    public Order createOrder(OrderCreateRequest request) {
        ProductClient.ProductDto product = productClient.getProduct(request.getProductId());

        productClient.reserveStock(request.getProductId(), request.getQuantity());

        BigDecimal totalAmount = product.getPrice().multiply(BigDecimal.valueOf(request.getQuantity()));

        Order order = new Order();
        order.setUserId(request.getUserId());
        order.setProductId(request.getProductId());
        order.setQuantity(request.getQuantity());
        order.setTotalAmount(totalAmount);
        order.setStatus(OrderStatus.CREATED);
        order = orderRepository.save(order);

        PaymentClient.PaymentResultDto payment = paymentClient.charge(order.getId(), totalAmount);

        order.setStatus(
                "SUCCESS".equals(payment.getStatus()) ? OrderStatus.CONFIRMED : OrderStatus.PAYMENT_FAILED
        );
        return orderRepository.save(order);
    }

    public List<Order> listOrders() {
        return orderRepository.findAll();
    }

    public Order getOrder(String id) {
        return orderRepository.findById(id).orElseThrow(() -> new OrderNotFoundException(id));
    }
}
