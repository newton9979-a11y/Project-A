package com.ecommerce.orderservice.client;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Synchronous REST client to product-service. Validates the product exists
 * and reserves (decrements) stock at order time.
 */
@Component
public class ProductClient {

    private final RestTemplate restTemplate;
    private final String productServiceUrl;

    public ProductClient(RestTemplate restTemplate,
                          @Value("${services.product-service.url}") String productServiceUrl) {
        this.restTemplate = restTemplate;
        this.productServiceUrl = productServiceUrl;
    }

    public ProductDto getProduct(String productId) {
        return restTemplate.getForObject(productServiceUrl + "/products/" + productId, ProductDto.class);
    }

    public void reserveStock(String productId, int quantity) {
        restTemplate.postForObject(
                productServiceUrl + "/products/" + productId + "/reserve",
                Map.of("quantity", quantity),
                ProductDto.class
        );
    }

    @Data
    public static class ProductDto {
        private String id;
        private String name;
        private BigDecimal price;
        private Integer stockQuantity;
    }
}
