package com.ecommerce.orderservice.model;

public enum OrderStatus {
    CREATED,
    PAYMENT_FAILED,
    CONFIRMED,
    CANCELLED
}
