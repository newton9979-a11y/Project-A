package com.ecommerce.orderservice.client;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Map;

/** Synchronous REST client to payment-service. */
@Component
public class PaymentClient {

    private final RestTemplate restTemplate;
    private final String paymentServiceUrl;

    public PaymentClient(RestTemplate restTemplate,
                          @Value("${services.payment-service.url}") String paymentServiceUrl) {
        this.restTemplate = restTemplate;
        this.paymentServiceUrl = paymentServiceUrl;
    }

    public PaymentResultDto charge(String orderId, BigDecimal amount) {
        return restTemplate.postForObject(
                paymentServiceUrl + "/payments",
                Map.of("orderId", orderId, "amount", amount),
                PaymentResultDto.class
        );
    }

    @Data
    public static class PaymentResultDto {
        private String id;
        private String orderId;
        private BigDecimal amount;
        private String status; // SUCCESS | FAILED
    }
}
