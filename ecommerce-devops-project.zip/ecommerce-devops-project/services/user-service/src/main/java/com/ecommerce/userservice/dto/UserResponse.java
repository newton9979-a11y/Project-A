package com.ecommerce.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
public class UserResponse {
    private String id;
    private String fullName;
    private String email;
    private Instant createdAt;
}
