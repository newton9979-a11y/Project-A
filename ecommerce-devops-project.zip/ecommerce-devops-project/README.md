# E-Commerce DevOps Microservices Project

A 5-service Java/Spring Boot e-commerce backend + React frontend, built as a
DevOps/SRE portfolio project. This repo is being built in phases — this is
**Step 1: application code + Docker (local run)**.

## Architecture (this phase)

```
React frontend (nginx)
        │
        ├──────────────► user-service    (MySQL)
        ├──────────────► product-service (MySQL)
        ├──────────────► cart-service    (Redis)
        └──────────────► order-service   (MySQL)
                                │
                                ├──► product-service   (validate + reserve stock)
                                └──► payment-service    (MySQL)  (charge)
```

- **user-service** — user registration/lookup. Spring Data JPA + MySQL.
- **product-service** — product catalog + stock. Exposes a `/reserve` endpoint
  that order-service calls to atomically decrement stock at order time.
- **cart-service** — shopping cart, backed by Redis (24h TTL per cart) instead
  of a relational DB — this is intentional, to demonstrate polyglot persistence.
- **order-service** — the orchestrator. On order creation it: looks up the
  product, reserves stock, saves the order, charges payment-service, then
  updates the order to `CONFIRMED` or `PAYMENT_FAILED` based on the result.
  This is a simple synchronous saga — see the code comments in `OrderService.java`
  for why you'd likely evolve this to async choreography via a queue later
  (same conversation point we used in the earlier Python version of this project).
- **payment-service** — mock payment processor. Approves anything ≤ $10,000,
  declines above it, so you can demo both the success and failure paths.

Every service exposes Spring Boot Actuator's `/actuator/health` — this is what
Kubernetes liveness/readiness probes will target in the next phase.

## Running locally

Requires Docker and Docker Compose. From the `docker/` directory:

```bash
cd docker
docker compose up --build
```

First build will be slow (Maven downloads dependencies for 5 services). Subsequent
builds are cached.

Services will be available at:
- Frontend: http://localhost:3000
- user-service: http://localhost:8081
- product-service: http://localhost:8082
- cart-service: http://localhost:8083
- order-service: http://localhost:8084
- payment-service: http://localhost:8085

### Try the full flow end to end

```bash
# 1. create a product
curl -X POST http://localhost:8082/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Mechanical Keyboard","description":"Blue switches","price":89.99,"stockQuantity":10}'
# copy the returned "id" -> PRODUCT_ID

# 2. create a user
curl -X POST http://localhost:8081/users \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Jane Doe","email":"jane@example.com","password":"secret123"}'
# copy the returned "id" -> USER_ID

# 3. place an order (this triggers the full saga: reserve stock -> charge payment)
curl -X POST http://localhost:8084/orders \
  -H "Content-Type: application/json" \
  -d '{"userId":"<USER_ID>","productId":"<PRODUCT_ID>","quantity":2}'
```

The response's `status` field will be `CONFIRMED` (payment succeeded) or
`PAYMENT_FAILED`. Check `product-service`'s `stockQuantity` afterward —
it should have dropped by the quantity ordered.

## Known limitation worth knowing about

The frontend's `REACT_APP_*` env vars in `docker-compose.yaml` are **baked in
at build time** by Create React App, not read at container runtime — setting
them in `environment:` has no effect once the image is built. For local dev
this is fine since the defaults in `src/api.js` already point at the right
ports. You'll want to fix this properly (e.g. via a runtime `env.js` injected
by nginx, or a build-arg) before this matters for QA/prod environments.

## Roadmap

- [x] Step 1: Application code (5 Java services + React frontend)
- [x] Step 2: Docker (Dockerfiles + docker-compose)
- [ ] Step 3: Kubernetes manifests (namespaces, deployments, services, ingress, HPA)
- [ ] Step 4: Terraform (VPC, EKS, ECR, RDS, ElastiCache, IAM modules across dev/qa/prod)
- [ ] Step 5: Jenkins CI/CD (build → SonarQube → Docker → Trivy → ECR → EKS)
- [ ] Step 6: Monitoring (Prometheus + Grafana + alerts)
- [ ] Step 7: Ansible + scripts + security scanning + docs

## Repo structure

```
ecommerce-devops-project/
├── frontend/                  React app (nginx-served in prod)
├── services/
│   ├── user-service/          Spring Boot + MySQL
│   ├── product-service/       Spring Boot + MySQL
│   ├── cart-service/          Spring Boot + Redis
│   ├── order-service/         Spring Boot + MySQL, orchestrates the other 3
│   └── payment-service/       Spring Boot + MySQL, mock payment processing
└── docker/
    ├── docker-compose.yaml
    └── .env
```

Each service follows the same internal layout:
```
services/<name>/
├── Dockerfile              multi-stage: maven build -> jre-alpine runtime
├── pom.xml
└── src/
    ├── main/java/com/ecommerce/<name>/
    │   ├── <Name>Application.java
    │   ├── controller/
    │   ├── service/
    │   ├── repository/
    │   ├── model/
    │   ├── dto/
    │   └── exception/
    ├── main/resources/application.yml
    └── test/java/...          smoke test (Spring context loads)
```
